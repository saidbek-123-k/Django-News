from django.shortcuts import render, redirect
from .forms import RegisterForm, LoginForm
from .models import CustomUser
from django.contrib import messages

def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Ro‘yxatdan o‘tish muvaffaqiyatli!')
            return redirect('login')
    else:
        form = RegisterForm()
    return render(request, 'accounts/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            user = CustomUser.objects.filter(email=email, password=password).first()
            if user:
                request.session['user_id'] = user.id
                messages.success(request, 'Muvaffaqiyatli kirdingiz!')
                return redirect('home')
            else:
                messages.error(request, 'Email yoki parol noto‘g‘ri!')
    else:
        form = LoginForm()
    return render(request, 'accounts/login.html', {'form': form})
